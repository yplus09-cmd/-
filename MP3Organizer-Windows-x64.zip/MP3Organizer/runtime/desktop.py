"""Local-only desktop entry point for the portable Windows package."""
import threading
import webbrowser

from werkzeug.serving import make_server

from app import app


def main():
    # Ask the OS for a free port. Bind only to this PC, never the LAN.
    server = make_server('127.0.0.1', 0, app, threaded=True)
    url = f'http://127.0.0.1:{server.server_port}/'
    print('MP3 Organizer is running on this PC only.', flush=True)
    print(f'Open in your browser: {url}', flush=True)
    print('Keep this window open. Close it or press Ctrl+C to stop.', flush=True)
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
