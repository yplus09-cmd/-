import io
import re
import zipfile
from pathlib import PurePosixPath

from flask import Flask, request, send_file, render_template
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, ID3NoHeaderError, TIT2, TPE1, TCON, TDRC

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 512 * 1024 * 1024
FIELDS = {'title': TIT2, 'artist': TPE1, 'genre': TCON, 'year': TDRC}


@app.get('/')
def index():
    return render_template('index.html')


@app.post('/convert')
def convert():
    files = request.files.getlist('files')
    if not files or not any(f.filename for f in files):
        return 'MP3 파일을 선택해 주세요.', 400
    year = request.form.get('year', '').strip()
    if year and not re.fullmatch(r'\d{4}', year):
        return '연도는 네 자리 숫자로 입력해 주세요.', 400
    output = io.BytesIO()
    used = set()
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_STORED) as archive:
        for upload in files:
            name = PurePosixPath(upload.filename.replace('\\', '/')).name
            if not name.lower().endswith('.mp3'):
                return 'MP3 파일만 선택해 주세요.', 400
            stream = io.BytesIO(upload.read())
            try:
                MP3(stream)  # Reject files that are not MPEG audio.
                stream.seek(0)
                try:
                    tags = ID3(stream)
                except ID3NoHeaderError:
                    tags = ID3()
                for field, frame in FIELDS.items():
                    value = request.form.get(field, '').strip()
                    if value:
                        tags.delall(frame.__name__)
                        tags.add(frame(encoding=1, text=[value]))
                stream.seek(0)
                tags.save(stream, v2_version=3, v1=2)
            except Exception:
                return f'올바른 MP3인지 확인해 주세요: {name}', 400
            if request.form.get('rename'):
                title = str(tags.get('TIT2', '')).strip()
                artist = str(tags.get('TPE1', '')).strip()
                if title and artist:
                    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', '_', f'{artist} - {title}')[:180] + '.mp3'
            base = name[:-4]
            number = 2
            while name.casefold() in used:
                name = f'{base} ({number}).mp3'
                number += 1
            used.add(name.casefold())
            archive.writestr(name, stream.getvalue())
    output.seek(0)
    return send_file(output, mimetype='application/zip', as_attachment=True, download_name='mp3-organized.zip')


@app.errorhandler(413)
def too_large(error):
    return '한 번에 최대 512MB까지 업로드할 수 있습니다. 파일을 나누어 선택해 주세요.', 413


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
